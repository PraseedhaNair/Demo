package com.example.SpringSecurity;

import org.springframework.data.jpa.repository.*;

public interface UserRepository extends JpaRepository<User, Integer> {
         
    @Query("UPDATE User u SET u.failedAttempt = ?1 WHERE u.email = ?2")
    @Modifying
    public void updateFailedAttempts(int failAttempts, String email);
    
    
    @Query("Select * frm user u where u.firstName = ?1")
    public User findByUsername(String firstName);
     
}