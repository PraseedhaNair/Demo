package com.example.AccountStatements.Entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class Account {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer ID;
	private String account_type;
	private String account_number;
	
	@OneToMany(mappedBy="account")
	private List<Statement> statement;
	public Account() {
		
	}
	public Account(Integer iD, String account_type, String account_number) {
		super();
		ID = iD;
		this.account_type = account_type;
		this.account_number = account_number;
	}
	public String getAccount_type() {
		return account_type;
	}
	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}
	public String getAccount_number() {
		return account_number;
	}
	public void setAccount_number(String account_number) {
		this.account_number = account_number;
	}
	
	
	

	public Integer getID() {
		return ID;
	}
	public void setID(Integer iD) {
		ID = iD;
	}
	@Override
	public String toString() {
		return "Account [ID=" + ID + ", account_type=" + account_type + ", account_number=" + account_number
				+ ", statement=" + statement + "]";
	}
	public List<Statement> getStatement() {
		return statement;
	}
	public void setStatement(List<Statement> statement) {
		this.statement = statement;
	}

	
	

}
