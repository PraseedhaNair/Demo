package com.example.AccountStatements.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.AccountStatements.Entity.Statement;


@Repository
public interface StatementDao extends JpaRepository<Statement, Integer>{
	
	
	public final static String GET_STATEMENTS_BETWEEN = "From Statement s  where s.dateField between ?1 and ?2 order by s.dateField";
	public final static String GET_STATEMENTS_3MONTHS = "From Statement s  where s.account.ID=?1 and s.dateField=?2";
	public final static String GET_STATEMENTS_3MONTHSFILTERED = "From Statement s  where  s.dateField =?1 and s.dateField>=DATEADD(MONTH,-3,GETDATE())";//sysdate-30
	public final static String GET_STATEMENTS_AMOUNT = "FROM Statement s where s.account.ID=?1 and s.amount=?2";
	@Query(GET_STATEMENTS_BETWEEN)
	List<Statement> findByFromAndTo(String from, String to);
	
	@Query(GET_STATEMENTS_3MONTHS)
	List<Statement> findStatements(String id,String dateField);
	
	@Query(GET_STATEMENTS_3MONTHSFILTERED)
	List<Statement> findStatementsFiltered(String dateField);
	
	@Query(GET_STATEMENTS_AMOUNT)
	List<Statement> findStatementsAmount(String id,String amount);
	

}
