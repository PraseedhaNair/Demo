package com.example.AccountStatements.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.AccountStatements.Entity.Account;
import com.example.AccountStatements.dao.AccountDao;

@Service
@Transactional
public class AccountService {

	
	@Autowired
    private AccountDao repo;
     
    public List<Account> listAll() {
        return repo.findAll();
    }
     
    public void save(Account product) {
        repo.save(product);
    }
     
    public Account get(Integer id) {
        return repo.findById(id).get();
    }
     
    public void delete(Integer id) {
        repo.deleteById(id);
    }

}
