package com.example.AccountStatements.Controller;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.AccountStatements.Entity.Account;
import com.example.AccountStatements.Entity.Statement;
import com.example.AccountStatements.Exceptions.AccNotFoundException;
import com.example.AccountStatements.dao.AccountDao;
import com.example.AccountStatements.dao.StatementDao;


@RestController
@RequestMapping(value="/list")
public class MainController {
	
	 @Autowired
	 private AccountDao repo;
	 @Autowired
	 private StatementDao strepo;
	 
	 
	 @GetMapping("/accountstmts/accounts")
		public List<Account> retrieveAllAccounts() {
			return repo.findAll();
		}

		@GetMapping("/accountstmts/accounts/{id}")
		public List<Statement> retrieveAccountStatements(@PathVariable int id) {
			Optional<Account> account = repo.findById(id);
			if(!account.isPresent()) {
				throw new AccNotFoundException("id-" + id);
			}
			
			return account.get().getStatement();
			
		}
		
		@GetMapping("/accountstmts/accounts/id/{id}/from/{from}/to/{to}")
		public List<Statement> retrieveAccountStatementsDateRanges(@PathVariable int id,
				@PathVariable String dateField,
				@PathVariable String from,
				@PathVariable String to) {
			
			List<Statement> s= strepo.findAll();
			List<Statement> statementList=new ArrayList<>();
			
			if(from!=null && to!=null) {
			
			
			for (Statement statement : s) {
			
				if(statement.getAccount().getID().equals(id)) {
				
				List<Statement> statementbetweenRanges=strepo.findByFromAndTo(from, to);
				for (Statement statement2 : statementbetweenRanges) {
					statementList.add(statement2);
						}
					}
				}
			}else {
				List<Statement> listOfStmts=strepo.findStatements(String.valueOf(id),dateField);
				 for (Statement statement : listOfStmts) {
					List<Statement> filteredStmts=strepo.findStatementsFiltered(statement.getDateField());
					for (Statement statement3 : filteredStmts) {
						statementList.add(statement3);
					}
					
				}
			}
			return statementList;
			
		}
		
		@GetMapping("/accountstmts/id/{id}/amount/{amount}")
		public List<Statement> retrieveAccountStatementsDateByAmount(@PathVariable int id,
				@PathVariable String amount) {
			
			List<Statement> stmtWithAmount= strepo.findStatementsAmount(String.valueOf(id),amount);
			
			return stmtWithAmount;
			
		}
		@PostMapping("/destroy")
		public String destroySession(HttpServletRequest request) {
			request.getSession().invalidate();
			return "redirect:/";
		}

}
