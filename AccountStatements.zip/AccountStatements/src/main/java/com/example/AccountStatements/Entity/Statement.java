package com.example.AccountStatements.Entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Statement {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer ID;
	private String dateField;
	private String amount;
	//private String account_id;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="account_id")
	private Account account;
	
	public Statement() {
		
	}

	
	

	public Statement(Integer iD, String dateField, String amount, Account account) {
		super();
		ID = iD;
		this.dateField = dateField;
		this.amount = amount;
		this.account = account;
	}




	public Integer getID() {
		return ID;
	}

/*	public Statement(Integer iD, String dateField, String amount, Account account) {
		super();
		ID = iD;
		this.dateField = dateField;
		this.amount = amount;
		this.account = account;
	}*/

	public void setID(Integer iD) {
		ID = iD;
	}

	public String getDateField() {
		return dateField;
	}

	public void setDateField(String dateField) {
		this.dateField = dateField;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	@Override
	public String toString() {
		return "Statement [ID=" + ID + ", dateField=" + dateField + ", amount=" + amount + ", account=" + account + "]";
	}




	

	

	

	
	
	

}
