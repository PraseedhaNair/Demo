
CREATE TABLE account (
id INT NOT NULL,
account_type VARCHAR(50) NOT NULL,
account_number VARCHAR(20) NOT NULL

);

CREATE TABLE statement (
id INT NOT NULL,
dateField VARCHAR(50) NOT NULL,
amount VARCHAR(20) NOT NULL,
account_id VARCHAR(20) NOT NULL
);

insert into account values(1, 'savings', '0145264785');
insert into account values(2, 'current', '0154785962');
insert into account values(3, 'savings', '0178457652');
insert into account values(4,'current', '0178497456');

insert into statement values(1, '09.08.2020',' 535.197875027054',1);
insert into statement values(2, '09.08.2021', '4785.45',1);