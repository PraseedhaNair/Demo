package com.example.AccountStatements;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountStatementsApplicationTests {

	@Test
	void contextLoads() {
	}

}
