package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.example.Entity.Account;
import com.example.Entity.Statement;


@SpringBootApplication
//@ComponentScan
//@ComponentScan(value = "dao.AccountDao")
public class StatementProjectApplication implements CommandLineRunner{
	
	
	 @Autowired 
	 private JdbcTemplate jdbcTemplate;
	 
	
	//@Autowired
	//private AccountService accountService;
	
	//@Autowired
	//private AccountController accnt;
	
	
	public static void main(String[] args) {
		SpringApplication.run(StatementProjectApplication.class, args);
	}


	

	@Override
	public void run(String... args) throws Exception {
		//jdbcTemplate.update("Insert into account(account_type,account_number)values('savings','14578945')");
		String query="Select a.ID,a.account_type,a.account_number from account a";
		List<Statement> statement = new ArrayList<Statement>();
		Statement s=new Statement();
	List<Account> accounts=jdbcTemplate.query(query,new RowMapper<Account>() {
		
			@Override
			public Account mapRow(ResultSet rs, int rowNum) throws SQLException {
				
				return new Account(rs.getInt("ID"),rs.getString("account_type"),rs.getString("account_number"));
				//s.setAccount(ac);
				
				
			}
			
		});
	
		
		accounts.forEach(System.out::println);
		List<Statement> sts=null;
		for (Iterator iterator = accounts.iterator(); iterator.hasNext();) {
			Account account = (Account) iterator.next();
			Integer id=account.getID();
			String idstr=String.valueOf(id);
			 
			System.out.println("id-->"+id);
			
			
	
		sts=jdbcTemplate.query("",new RowMapper<Statement>() {
			
			@Override
			public Statement mapRow(ResultSet rs, int rowNum) throws SQLException {
				
				return new Statement(rs.getInt("ID"),rs.getString("dateField"),rs.getString("amount"),rs.getString("account_id"));
				//s.setAccount(ac);
				
				
			}
			
		});
		
		}
		
		sts.forEach(System.out::println);
	}

}
