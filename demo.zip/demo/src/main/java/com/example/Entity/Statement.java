package com.example.Entity;

public class Statement {
	
	private Integer ID;
	private String dateField;
	private String amount;
	private String account_id;
	
	
	private Account account;
	
	public Statement() {
		
	}

	public Statement(Integer iD, String dateField, String amount, String account_id) {
		super();
		ID = iD;
		this.dateField = dateField;
		this.amount = amount;
		this.account_id = account_id;
	}
	

	public Integer getID() {
		return ID;
	}

/*	public Statement(Integer iD, String dateField, String amount, Account account) {
		super();
		ID = iD;
		this.dateField = dateField;
		this.amount = amount;
		this.account = account;
	}*/

	public void setID(Integer iD) {
		ID = iD;
	}

	public String getDateField() {
		return dateField;
	}

	public void setDateField(String dateField) {
		this.dateField = dateField;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public String getAccount_id() {
		return account_id;
	}

	public void setAccount_id(String account_id) {
		this.account_id = account_id;
	}

	@Override
	public String toString() {
		return "Statement [ID=" + ID + ", dateField=" + dateField + ", amount=" + amount + ", account_id=" + account_id
				+ ", account=" + account + "]";
	}

	
	
	

}
