package com.example.Entity;

import java.util.ArrayList;
import java.util.List;

public class Account {
	private Integer ID;
	private String account_type;
	private String account_number;
	List<Statement> statement =new ArrayList<Statement>();
	
	public List<Statement> getStatement() {
		return statement;
	}
	public void setStatement(List<Statement> statement) {
		this.statement = statement;
	}
	public Account() {
		
	}
	public Account(Integer iD, String account_type, String account_number) {
		super();
		ID = iD;
		this.account_type = account_type;
		this.account_number = account_number;
	}
	public String getAccount_type() {
		return account_type;
	}
	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}
	public String getAccount_number() {
		return account_number;
	}
	public void setAccount_number(String account_number) {
		this.account_number = account_number;
	}
	
	
	

	public Integer getID() {
		return ID;
	}
	public void setID(Integer iD) {
		ID = iD;
	}
	@Override
	public String toString() {
		return "Account [ID=" + ID + ", account_type=" + account_type + ", account_number=" + account_number
				+ ", statement=" + statement + "]";
	}
	
	

}
